﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Technorix.Models.Models
{
    public class OutputDto
    {
        public string OutputMsg { get; set; }
        public int? Id { get; set; }
    }
}
